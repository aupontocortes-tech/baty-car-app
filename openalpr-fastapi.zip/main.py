from fastapi import FastAPI, UploadFile, File, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import base64, os, tempfile, subprocess, json

app = FastAPI()
orig = os.environ.get("ALLOWED_ORIGIN", "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[orig] if orig else ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return JSONResponse({"ok": True})

def save_temp_bytes(b: bytes) -> str:
    fd, path = tempfile.mkstemp(suffix=".jpg")
    os.write(fd, b)
    os.close(fd)
    return path

def run_alpr(image_path: str, region: str) -> dict:
    cmd = ["alpr", "-j", "-c", region, image_path]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise Exception(p.stderr or p.stdout)
    return json.loads(p.stdout)

def extract_best(result: dict) -> dict:
    arr = result.get("results") or []
    best = None
    for r in arr:
        conf = r.get("confidence")
        plate = r.get("plate")
        if plate is None:
            continue
        if best is None or (isinstance(conf, (int,float)) and conf > best.get("confidence", 0)):
            best = {"plate": plate, "confidence": float(conf or 0)}
    return best or {"plate": "", "confidence": 0.0}

@app.post("/read-plate")
async def read_plate(request: Request, file: UploadFile | None = File(default=None)):
    region_raw = (request.query_params.get("region") or "br").lower()
    # map 'br' to eu/us fallback for local OpenALPR
    order = ["eu", "us"] if region_raw == "br" else [region_raw, "us"]
    body = None
    ct = (request.headers.get("content-type") or "").lower()
    if file is not None:
        body = await file.read()
    elif "application/octet-stream" in ct:
        body = await request.body()
    else:
        try:
            j = await request.json()
            raw = str(j.get("image") or "")
            raw = raw.split(",")[-1]
            body = base64.b64decode(raw)
        except Exception:
            body = None
    if not body:
        return JSONResponse({"error": "missing_image"}, status_code=400)
    path = save_temp_bytes(body)
    try:
        result = None
        best = None
        for r in order:
            try:
                candidate = run_alpr(path, r)
                b = extract_best(candidate)
                result = candidate
                best = b
                if b.get("plate"):
                    break
            except Exception:
                continue
        if not result:
            return JSONResponse({"error": "no_plate", "detail": "Nenhuma placa encontrada"}, status_code=200)
        return JSONResponse({"plate": best.get("plate", ""), "confidence": best.get("confidence", 0.0), "raw": result})
    except Exception as e:
        return JSONResponse({"error": "alpr_failed", "detail": str(e)}, status_code=500)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass

@app.get("/health")
async def health():
    try:
        p = subprocess.run(["alpr", "-v"], capture_output=True, text=True)
        return JSONResponse({"ok": True, "alpr_version": p.stdout.strip() or p.stderr.strip()})
    except Exception as e:
        return JSONResponse({"ok": False, "detail": str(e)})
